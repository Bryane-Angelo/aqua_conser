import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Droplets } from "lucide-react";

interface TankLevelProps {
  name: string;
  capacity: number;
  currentLevel: number;
  location: string;
}

const TankLevel = ({ name, capacity, currentLevel, location }: TankLevelProps) => {
  const [animatedLevel, setAnimatedLevel] = useState(0);
  const percentage = (currentLevel / capacity) * 100;

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedLevel(percentage);
    }, 100);
    return () => clearTimeout(timer);
  }, [percentage]);

  const getStatusColor = (pct: number) => {
    if (pct < 20) return "text-destructive";
    if (pct < 40) return "text-chart-warning";
    return "text-accent";
  };

  const getBarColor = (pct: number) => {
    if (pct < 20) return "bg-destructive";
    if (pct < 40) return "bg-chart-warning";
    return "bg-gradient-accent";
  };

  return (
    <Card variant="stat" className="group">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
              <Droplets className="w-5 h-5 text-accent" />
            </div>
            <div>
              <CardTitle className="text-base">{name}</CardTitle>
              <p className="text-xs text-muted-foreground">{location}</p>
            </div>
          </div>
          <span className={`text-2xl font-bold ${getStatusColor(percentage)}`}>
            {Math.round(percentage)}%
          </span>
        </div>
      </CardHeader>
      <CardContent>
        {/* Tank visualization */}
        <div className="relative h-32 rounded-xl bg-secondary/50 border border-border overflow-hidden mb-4">
          {/* Water level */}
          <div
            className={`absolute bottom-0 left-0 right-0 ${getBarColor(percentage)} transition-all duration-1000 ease-out`}
            style={{ height: `${animatedLevel}%` }}
          >
            {/* Wave animation */}
            <div className="absolute top-0 left-0 right-0 h-3 overflow-hidden">
              <svg
                className="w-[200%] h-full water-wave"
                viewBox="0 0 200 10"
                preserveAspectRatio="none"
              >
                <path
                  d="M0 5 Q25 0 50 5 T100 5 T150 5 T200 5 V10 H0 Z"
                  fill="currentColor"
                  className="text-card/20"
                />
              </svg>
            </div>
          </div>

          {/* Level markers */}
          <div className="absolute inset-0 flex flex-col justify-between py-2 px-3 text-xs text-muted-foreground/50">
            <span>100%</span>
            <span>50%</span>
            <span>0%</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Current</p>
            <p className="font-semibold text-foreground">
              {currentLevel.toLocaleString()} L
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Capacity</p>
            <p className="font-semibold text-foreground">
              {capacity.toLocaleString()} L
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TankLevel;
