import { useState } from "react";
import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import AlertCard from "@/components/alerts/AlertCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Filter, CheckCircle2 } from "lucide-react";

const Alerts = () => {
  const [alerts, setAlerts] = useState([
    {
      id: "1",
      type: "leak" as const,
      title: "Potential Leak Detected",
      description: "Abnormal flow rate detected in Hostel Block B supply line. Immediate inspection recommended.",
      location: "Hostel Block B, Floor 2",
      severity: "critical" as const,
      timestamp: "2 minutes ago",
      acknowledged: false,
    },
    {
      id: "2",
      type: "low_level" as const,
      title: "Low Water Level Warning",
      description: "Reserve tank approaching minimum threshold. Auto-refill scheduled for off-peak hours.",
      location: "Hostel Reserve Tank",
      severity: "warning" as const,
      timestamp: "15 minutes ago",
      acknowledged: false,
    },
    {
      id: "3",
      type: "high_consumption" as const,
      title: "Unusual Consumption Pattern",
      description: "Laboratory building showing 45% higher consumption than predicted for this time period.",
      location: "Science Complex",
      severity: "info" as const,
      timestamp: "1 hour ago",
      acknowledged: true,
    },
    {
      id: "4",
      type: "pump_failure" as const,
      title: "Pump Maintenance Due",
      description: "Scheduled maintenance required for Pump #3. Last service was 90 days ago.",
      location: "Central Plant",
      severity: "info" as const,
      timestamp: "3 hours ago",
      acknowledged: true,
    },
  ]);

  const handleAcknowledge = (id: string) => {
    setAlerts(alerts.map(alert =>
      alert.id === id ? { ...alert, acknowledged: true } : alert
    ));
  };

  const handleDismiss = (id: string) => {
    setAlerts(alerts.filter(alert => alert.id !== id));
  };

  const activeAlerts = alerts.filter(a => !a.acknowledged);
  const acknowledgedAlerts = alerts.filter(a => a.acknowledged);

  return (
    <>
      <Helmet>
        <title>Alerts | Aqua Conserva</title>
        <meta
          name="description"
          content="Real-time alerts and notifications for campus water management system."
        />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 md:pt-28 pb-12">
          <div className="container px-4 md:px-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                  Alert Center
                </h1>
                <p className="text-muted-foreground">
                  Monitor and manage system notifications and warnings.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  Filter
                </Button>
                <Button variant="default" className="gap-2">
                  <Bell className="w-4 h-4" />
                  Settings
                </Button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              <Card variant="stat">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                    <Bell className="w-6 h-6 text-destructive" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {alerts.filter(a => a.severity === "critical" && !a.acknowledged).length}
                    </p>
                    <p className="text-sm text-muted-foreground">Critical Alerts</p>
                  </div>
                </CardContent>
              </Card>
              <Card variant="stat">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-chart-warning/10 flex items-center justify-center">
                    <Bell className="w-6 h-6 text-chart-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{activeAlerts.length}</p>
                    <p className="text-sm text-muted-foreground">Active Alerts</p>
                  </div>
                </CardContent>
              </Card>
              <Card variant="stat">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-chart-tertiary/10 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-chart-tertiary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{acknowledgedAlerts.length}</p>
                    <p className="text-sm text-muted-foreground">Resolved Today</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Active Alerts */}
            {activeAlerts.length > 0 && (
              <section className="mb-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  Active Alerts
                </h2>
                <div className="space-y-4">
                  {activeAlerts.map(alert => (
                    <AlertCard
                      key={alert.id}
                      {...alert}
                      onAcknowledge={handleAcknowledge}
                      onDismiss={handleDismiss}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Acknowledged Alerts */}
            {acknowledgedAlerts.length > 0 && (
              <section>
                <h2 className="text-xl font-semibold text-foreground mb-4">
                  Acknowledged
                </h2>
                <div className="space-y-4">
                  {acknowledgedAlerts.map(alert => (
                    <AlertCard
                      key={alert.id}
                      {...alert}
                      onDismiss={handleDismiss}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        </main>
      </div>
    </>
  );
};

export default Alerts;
