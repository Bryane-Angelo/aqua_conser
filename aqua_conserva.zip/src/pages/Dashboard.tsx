import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import StatsOverview from "@/components/dashboard/StatsOverview";
import TankLevel from "@/components/dashboard/TankLevel";
import DemandChart from "@/components/dashboard/DemandChart";
import EnergySavings from "@/components/dashboard/EnergySavings";
import CampusHeatmap from "@/components/dashboard/CampusHeatmap";

const Dashboard = () => {
  const tanks = [
    { name: "Main Tank", capacity: 50000, currentLevel: 38500, location: "Central Plant" },
    { name: "Hostel Reserve", capacity: 30000, currentLevel: 8400, location: "Block A" },
    { name: "Lab Building", capacity: 20000, currentLevel: 14200, location: "Science Complex" },
    { name: "Sports Arena", capacity: 15000, currentLevel: 10800, location: "West Campus" },
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard | Aqua Conserva</title>
        <meta
          name="description"
          content="Real-time water monitoring dashboard with AI-powered demand forecasting, tank levels, and energy savings analytics."
        />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 md:pt-28 pb-12">
          <div className="container px-4 md:px-6">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                Live Monitoring Dashboard
              </h1>
              <p className="text-muted-foreground">
                Real-time water consumption and AI-powered forecasting insights.
              </p>
            </div>

            {/* Stats Overview */}
            <section className="mb-8">
              <StatsOverview />
            </section>

            {/* Charts Grid */}
            <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              <DemandChart />
              <EnergySavings />
            </section>

            {/* Tank Levels */}
            <section className="mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-4">Tank Levels</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {tanks.map((tank, index) => (
                  <TankLevel key={index} {...tank} />
                ))}
              </div>
            </section>

            {/* Heatmap */}
            <section>
              <CampusHeatmap />
            </section>
          </div>
        </main>
      </div>
    </>
  );
};

export default Dashboard;
