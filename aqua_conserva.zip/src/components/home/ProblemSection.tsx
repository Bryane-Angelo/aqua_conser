import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Clock, DollarSign, Droplets } from "lucide-react";

const ProblemSection = () => {
  const problems = [
    {
      icon: AlertTriangle,
      title: "Manual Estimation Errors",
      description: "Campus facilities rely on outdated manual methods, leading to significant over-pumping and water wastage.",
    },
    {
      icon: Clock,
      title: "Unpredictable Demand",
      description: "Seasonal variations, events, and changing occupancy make demand forecasting nearly impossible.",
    },
    {
      icon: DollarSign,
      title: "Rising Operational Costs",
      description: "Inefficient pump scheduling results in excessive energy consumption and inflated utility bills.",
    },
    {
      icon: Droplets,
      title: "Water Resource Depletion",
      description: "Without data-driven insights, groundwater reserves are depleted faster than they can recharge.",
    },
  ];

  return (
    <section className="py-24 md:py-32 bg-background relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-glow opacity-30" />

      <div className="container px-4 md:px-6 relative">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-destructive/10 text-destructive text-sm font-medium mb-4">
            The Challenge
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Campus Water Management is Broken
          </h2>
          <p className="text-lg text-muted-foreground">
            Traditional approaches to campus water distribution lead to massive inefficiencies, 
            environmental damage, and preventable costs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {problems.map((problem, index) => (
            <Card
              key={index}
              variant="stat"
              className="group fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6 md:p-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0 group-hover:bg-destructive/20 transition-colors">
                    <problem.icon className="w-6 h-6 text-destructive" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {problem.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {problem.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
