import { Card, CardContent } from "@/components/ui/card";
import { Droplets, Activity, AlertTriangle, CheckCircle } from "lucide-react";

const StatsOverview = () => {
  const stats = [
    {
      label: "Total Water Today",
      value: "45,230",
      unit: "Liters",
      change: "+12%",
      changeType: "neutral",
      icon: Droplets,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      label: "Active Pumps",
      value: "4",
      unit: "of 6",
      change: "2 idle",
      changeType: "neutral",
      icon: Activity,
      color: "text-chart-secondary",
      bgColor: "bg-chart-secondary/10",
    },
    {
      label: "Active Alerts",
      value: "2",
      unit: "issues",
      change: "1 critical",
      changeType: "negative",
      icon: AlertTriangle,
      color: "text-chart-warning",
      bgColor: "bg-chart-warning/10",
    },
    {
      label: "System Health",
      value: "98.5",
      unit: "%",
      change: "Optimal",
      changeType: "positive",
      icon: CheckCircle,
      color: "text-chart-tertiary",
      bgColor: "bg-chart-tertiary/10",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <Card
          key={index}
          variant="stat"
          className="fade-in"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-foreground">
                    {stat.value}
                  </span>
                  <span className="text-sm text-muted-foreground">{stat.unit}</span>
                </div>
                <p
                  className={`text-xs mt-1 ${
                    stat.changeType === "positive"
                      ? "text-chart-tertiary"
                      : stat.changeType === "negative"
                      ? "text-destructive"
                      : "text-muted-foreground"
                  }`}
                >
                  {stat.change}
                </p>
              </div>
              <div className={`w-10 h-10 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StatsOverview;
