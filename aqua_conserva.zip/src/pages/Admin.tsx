import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Droplets, Lock, Mail, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Admin = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Placeholder for auth logic
    console.log("Login attempt:", { email, password });
  };

  return (
    <>
      <Helmet>
        <title>Admin Login | Aqua Conserva</title>
        <meta
          name="description"
          content="Secure admin portal for campus facility managers to manage water infrastructure."
        />
      </Helmet>
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/3 left-1/4 w-80 h-80 rounded-full bg-accent/10 blur-3xl float" />
          <div className="absolute bottom-1/3 right-1/4 w-64 h-64 rounded-full bg-accent/5 blur-3xl float" style={{ animationDelay: "3s" }} />
        </div>

        <div className="relative z-10 w-full max-w-md">
          {/* Back link */}
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-primary-foreground/70 hover:text-primary-foreground mb-8 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>

          <Card variant="glass" className="glass-strong">
            <CardHeader className="text-center pb-2">
              <div className="w-16 h-16 rounded-2xl bg-gradient-accent flex items-center justify-center mx-auto mb-4 shadow-glow">
                <Droplets className="w-8 h-8 text-accent-foreground" />
              </div>
              <CardTitle className="text-2xl text-primary-foreground">
                Admin Portal
              </CardTitle>
              <CardDescription className="text-primary-foreground/60">
                Campus Facility Manager Access
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-primary-foreground/80">
                    Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-foreground/40" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@campus.edu"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 bg-primary-foreground/5 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/30 focus:border-accent"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-primary-foreground/80">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-foreground/40" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10 bg-primary-foreground/5 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/30 focus:border-accent"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-primary-foreground/40 hover:text-primary-foreground/60 transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-primary-foreground/60 cursor-pointer">
                    <input
                      type="checkbox"
                      className="rounded border-primary-foreground/20 bg-primary-foreground/5"
                    />
                    Remember me
                  </label>
                  <button
                    type="button"
                    className="text-accent hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                <Button type="submit" variant="hero" className="w-full" size="lg">
                  Sign In
                </Button>
              </form>

              <p className="text-center text-xs text-primary-foreground/50 mt-6">
                Authorized personnel only. All access is logged and monitored.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Admin;
