import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, TrendingDown, Leaf } from "lucide-react";

const EnergySavings = () => {
  const [displayValue, setDisplayValue] = useState(0);
  const targetValue = 2.47; // MW saved this month

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = targetValue / steps;
    let current = 0;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      current += increment;
      if (step >= steps) {
        setDisplayValue(targetValue);
        clearInterval(timer);
      } else {
        setDisplayValue(current);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, []);

  const stats = [
    { label: "Cost Savings", value: "₹48,500", icon: TrendingDown, color: "text-chart-tertiary" },
    { label: "CO₂ Reduced", value: "1.8 MT", icon: Leaf, color: "text-chart-tertiary" },
  ];

  return (
    <Card variant="glow" className="relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl" />

      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-accent" />
          Energy Savings
        </CardTitle>
      </CardHeader>
      <CardContent className="relative">
        <div className="text-center mb-6">
          <div className="text-5xl font-bold text-foreground mb-1 counter-animate">
            {displayValue.toFixed(2)}
            <span className="text-2xl text-accent ml-1">MW</span>
          </div>
          <p className="text-muted-foreground">Saved This Month</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-secondary/50 rounded-xl p-4 text-center"
            >
              <stat.icon className={`w-5 h-5 ${stat.color} mx-auto mb-2`} />
              <div className="text-lg font-semibold text-foreground">
                {stat.value}
              </div>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        <div className="mt-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-muted-foreground">Monthly Goal</span>
            <span className="font-medium text-accent">82%</span>
          </div>
          <div className="h-2 rounded-full bg-secondary overflow-hidden">
            <div
              className="h-full bg-gradient-accent rounded-full transition-all duration-1000"
              style={{ width: "82%" }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Target: 3.0 MW by month end
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default EnergySavings;
